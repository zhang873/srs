<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AltPlans extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::table('plans', function(Blueprint $table)
		{
		    // admission year
		    $table->smallInteger('admissionyear');
		    
		    /// admission semester
		    $table->string('admissionsemester', 3);
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::table('plans', function(Blueprint $table)
		{
		    // admission year
		    $table->drop_column('admissionyear');
		    
		    /// admission semester
		    $table->drop_column('admissionsemester');
		});
	}

}
