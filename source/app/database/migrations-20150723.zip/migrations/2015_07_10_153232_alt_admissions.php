<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AltAdmissions extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::table('admissions', function(Blueprint $table)
		{
		    // 考生號
			$table->string('ksh', 17)->nullable();
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::table('admissions', function(Blueprint $table)
		{
			$table->drop_column('ksh');
		});
	}

}
