<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateStateInfoTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
        //状态表
        Schema::create('state_info', function($table)
        {
            $table->engine = 'InnoDB';
            $table->increments ('id');
            $table->integer ('school_id')->unique()->unsigned()->index();;
            $table->tinyInteger ('school_selection');
            $table->tinyInteger ('school_confirmation');
            $table->tinyInteger ('province_student_selection');
            $table->tinyInteger ('school_student_selection');
            $table->tinyInteger ('student_status_changing');
            $table->timestamps();

            $table->foreign('school_id')->references('id')->on('campuses');
        });
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
        Schema::drop('state_info');
	}

}
